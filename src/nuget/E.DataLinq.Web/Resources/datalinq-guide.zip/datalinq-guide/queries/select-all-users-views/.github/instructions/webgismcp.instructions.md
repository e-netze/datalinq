---
applyTo: '**'
---
always output the data recieved from mcp server